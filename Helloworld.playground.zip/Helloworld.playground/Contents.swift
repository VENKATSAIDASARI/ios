import UIKit

var greeting = "Hello, playground"
print("Hello World!")
print("Welcome to IOS Class");
print(greeting)
